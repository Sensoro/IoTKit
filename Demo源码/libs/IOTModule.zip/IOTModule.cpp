#include "IOTModule.h"

#define _SS_TXPIN_ 10
#define _SS_RXPIN_ 11
#define _WAKE_UP_PIN 4

#ifdef UNO
IOTModule::IOTModule(): _ss(_SS_RXPIN_, _SS_TXPIN_), _wakeupPin(_WAKE_UP_PIN)
{
}
#endif

int IOTModule::begin(long baud_rate)
{
  pinMode(_wakeupPin, OUTPUT);
  digitalWrite(_wakeupPin, LOW);

#ifdef UNO
  if (baud_rate == 115200) {
    Serial.println(F("Don't use baudrate 115200 with Software Serial.\nAutomatically changed at 9600."));
    baud_rate = 9600;
  }
#endif

  _ss.begin(baud_rate);

  wakeUp();
  if (AT_RESP_OK != SendATCmdWaitResp(str_at, 500, 100, str_ok, 5)) {
    Serial.println("error");
    return -1;
  }
  sleep();
  return 0;
}

void IOTModule::wakeUp(void)
{
  digitalWrite(_wakeupPin, LOW);
  delay(100);
  digitalWrite(_wakeupPin, HIGH);
  delay(100);
}

void IOTModule::sleep(void)
{
  digitalWrite(_wakeupPin, HIGH);
  delay(100);
  digitalWrite(_wakeupPin, LOW);
  delay(100);
}

byte IOTModule::WaitResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout,
                         char const *expected_resp_string)
{
  byte status;
  byte ret_val;

  RxInit(start_comm_tmout, max_interchar_tmout);
  // wait until response is not finished
  do {
    status = IsRxFinished();
  } while (status == RX_NOT_FINISHED);

  if (status == RX_FINISHED) {
    if (IsStringReceived(expected_resp_string)) {
      ret_val = RX_FINISHED_STR_RECV;
    } else {
      Serial.print("error "); Serial.println(__LINE__);
      ret_val = RX_FINISHED_STR_NOT_RECV;
    }
  } else {
    Serial.print("error "); Serial.println(__LINE__);
    ret_val = RX_TMOUT_ERR;
  }
  return (ret_val);
}

byte IOTModule::WaitChunkResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout,
                              uint8_t len)
{
  byte status;
  byte ret_val;
  char *ch;

  RxInit(start_comm_tmout, max_interchar_tmout);
  // wait until response is not finished
  do {
    status = IsRxFinished();
  } while (status == RX_NOT_FINISHED);

  if (status == RX_FINISHED) {
    if (comm_buf_len) {
      ch = strstr((char *)(comm_buf + len), str_ok);
      if (ch != NULL) {
        ret_val = RX_FINISHED_STR_RECV;
      } else
      {
        ret_val = RX_FINISHED_STR_NOT_RECV;
      }
    }
  } else {
    Serial.println("error RX_TMOUT_ERR");
    ret_val = RX_TMOUT_ERR;
  }
  return (ret_val);
}

/**********************************************************
  Method sends AT command and waits for response

  return:
      AT_RESP_ERR_NO_RESP = -1,   // no response received
      AT_RESP_ERR_DIF_RESP = 0,   // response_string is different from the response
      AT_RESP_OK = 1,             // response_string was included in the response
**********************************************************/
char IOTModule::SendATCmdWaitResp(char const *AT_cmd_string,
                                  uint16_t start_comm_tmout,
                                  uint16_t max_interchar_tmout,
                                  char const *response_string,
                                  byte no_of_attempts)
{
  byte status;
  char ret_val = AT_RESP_ERR_NO_RESP;
  byte i;

  for (i = 0; i < no_of_attempts; i++) {
    // delay 500 msec. before sending next repeated AT command
    // so if we have no_of_attempts=1 tmout will not occurred
    if (i > 0) delay(500);

    _ss.println(AT_cmd_string);
    status = WaitResp(start_comm_tmout, max_interchar_tmout);
    if (status == RX_FINISHED) {
      // something was received but what was received?
      // ---------------------------------------------
      if (IsStringReceived(response_string)) {
        ret_val = AT_RESP_OK;
        break;  // response is OK => finish
      } else ret_val = AT_RESP_ERR_DIF_RESP;
    } else {
      // nothing was received
      // --------------------
      ret_val = AT_RESP_ERR_NO_RESP;
    }

  }

  WaitResp(1000, 5000);
  return (ret_val);
}


/**********************************************************
  Method sends AT command and waits for response

  return:
      AT_RESP_ERR_NO_RESP = -1,   // no response received
      AT_RESP_ERR_DIF_RESP = 0,   // response_string is different from the response
      AT_RESP_OK = 1,             // response_string was included in the response
**********************************************************/
char IOTModule::SendATCmdWaitResp(const __FlashStringHelper *AT_cmd_string,
                                  uint16_t start_comm_tmout,
                                  uint16_t max_interchar_tmout,
                                  char const *response_string,
                                  byte no_of_attempts)
{
  byte status;
  char ret_val = AT_RESP_ERR_NO_RESP;
  byte i;

  for (i = 0; i < no_of_attempts; i++) {
    // delay 500 msec. before sending next repeated AT command
    // so if we have no_of_attempts=1 tmout will not occurred
    if (i > 0) delay(500);

    _ss.println(AT_cmd_string);
    status = WaitResp(start_comm_tmout, max_interchar_tmout);
    if (status == RX_FINISHED) {
      // something was received but what was received?
      // ---------------------------------------------
      if (IsStringReceived(response_string)) {
        ret_val = AT_RESP_OK;
        break;  // response is OK => finish
      } else ret_val = AT_RESP_ERR_DIF_RESP;
    } else {
      // nothing was received
      // --------------------
      ret_val = AT_RESP_ERR_NO_RESP;
    }
  }
  return (ret_val);
}

byte IOTModule::WaitResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout)
{
  byte status;

  RxInit(start_comm_tmout, max_interchar_tmout);
  // wait until response is not finished
  do {
    status = IsRxFinished();
  } while (status == RX_NOT_FINISHED);
  return (status);
}

byte IOTModule::IsRxFinished(void)
{
  byte num_of_bytes;
  byte ret_val = RX_NOT_FINISHED;  // default not finished

  // Rx state machine
  // ----------------

  if (rx_state == RX_NOT_STARTED) {
    // Reception is not started yet - check tmout
    if (!_ss.available()) {
      // still no character received => check timeout

      if ((unsigned long)(millis() - prev_time) >= start_reception_tmout) {
        // timeout elapsed => GSM module didn't start with response
        // so communication is takes as finished
        //        comm_buf[comm_buf_len] = 0x00;
        ret_val = RX_TMOUT_ERR;
      }
    } else {
      // at least one character received => so init inter-character
      // counting process again and go to the next state
      prev_time = millis(); // init tmout for inter-character space
      rx_state = RX_ALREADY_STARTED;
    }
  }

  if (rx_state == RX_ALREADY_STARTED) {
    // Reception already started
    // check new received bytes
    // only in case we have place in the buffer
    num_of_bytes = _ss.available();
    // if there are some received bytes postpone the timeout
    if (num_of_bytes) prev_time = millis();

    // read all received bytes
    while (num_of_bytes) {
      num_of_bytes--;
      if (comm_buf_len < COMM_BUF_LEN) {
        // we have still place in the GSM internal comm. buffer =>
        // move available bytes from circular buffer
        // to the rx buffer
        *p_comm_buf = _ss.read();

        p_comm_buf++;
        comm_buf_len++;
        //        comm_buf[comm_buf_len] = 0x00;  // and finish currently received characters
        // so after each character we have
        // valid string finished by the 0x00
      } else {
        // comm buffer is full, other incoming characters
        // will be discarded
        // but despite of we have no place for other characters
        // we still must to wait until
        // inter-character tmout is reached

        // so just readout character from circular RS232 buffer
        // to find out when communication id finished(no more characters
        // are received in inter-char timeout)
        _ss.read();
      }
    }

    // finally check the inter-character timeout

    if ((unsigned long)(millis() - prev_time) >= interchar_tmout) {
      // timeout between received character was reached
      // reception is finished
      // ---------------------------------------------
      //      comm_buf[comm_buf_len] = 0x00;  // for sure finish string again
      // but it is not necessary
      ret_val = RX_FINISHED;
    }
  }


  return (ret_val);
}

/**********************************************************
  Method checks received bytes

  compare_string - pointer to the string which should be find

  return: 0 - string was NOT received
        1 - string was received
**********************************************************/
byte IOTModule::IsStringReceived(char const *compare_string)
{
  char *ch;
  byte ret_val = 0;

  if (comm_buf_len) {
    ch = strstr((char *)comm_buf, compare_string);
    if (ch != NULL) {
      ret_val = 1;
    } else {
    }
  } else {

  }
  return (ret_val);
}


void IOTModule::RxInit(uint16_t start_comm_tmout, uint16_t max_interchar_tmout)
{
  rx_state = RX_NOT_STARTED;
  start_reception_tmout = start_comm_tmout;
  interchar_tmout = max_interchar_tmout;
  prev_time = millis();
  memset(comm_buf, 0, sizeof(comm_buf));
  p_comm_buf = &comm_buf[0];
  comm_buf_len = 0;
  _ss.flush(); // erase rx circular buffer
}

int IOTModule::available()
{
  return _ss.available();
}

uint8_t IOTModule::read()
{
  return _ss.read();
}

void IOTModule::SimpleRead()
{
  char datain;
  if (_ss.available() > 0) {
    datain = _ss.read();
    if (datain > 0) {
      Serial.print(datain);
    }
  }
}

void IOTModule::SimpleWrite(uint8_t *p_buff, uint8_t len)
{
  for (uint8_t i = 0; i < len; i++)
  {
    _ss.write(p_buff[i]);
  }
}

void IOTModule::SimpleWrite(char *comm)
{
  _ss.print(comm);
}

void IOTModule::SimpleWrite(const char *comm)
{
  _ss.print(comm);
}

void IOTModule::SimpleWrite(int comm)
{
  _ss.print(comm);
}

void IOTModule::SimpleWrite(const __FlashStringHelper *pgmstr)
{
  _ss.print(pgmstr);
}

void IOTModule::SimpleWriteln(char *comm)
{
  _ss.println(comm);
}

void IOTModule::SimpleWriteln(const __FlashStringHelper *pgmstr)
{
  _ss.println(pgmstr);
}

void IOTModule::SimpleWriteln(char const *comm)
{
  _ss.println(comm);
}

void IOTModule::SimpleWriteln(int comm)
{
  _ss.println(comm);
}

void IOTModule::WhileSimpleRead()
{
  char datain;
  while (_ss.available() > 0) {
    datain = _ss.read();
    if (datain > 0) {
      Serial.print(datain);
    }
  }
}

uint32_t IOTModule::uint32_decode(const uint8_t * p_encoded_data)
{
  return ( (((uint32_t)((uint8_t *)p_encoded_data)[0]) << 0)  |
           (((uint32_t)((uint8_t *)p_encoded_data)[1]) << 8)  |
           (((uint32_t)((uint8_t *)p_encoded_data)[2]) << 16) |
           (((uint32_t)((uint8_t *)p_encoded_data)[3]) << 24 ));
}

int IOTModule::IotSend(uint8_t *p_buff, uint8_t len, bool ack, uint32_t id)
{
  char buff[50];

  Serial.print("id ="); Serial.println(id);

  if (id != 0) {
    Serial.println("id != 0");
    sprintf(buff, "AT+SEND=%u,%u,%lu", len, ack, id);
  } else {
    sprintf(buff, "AT+SEND=%u,%u", len, ack);
  }
  Serial.print("write buff:");
  Serial.println(buff);

  if (AT_RESP_OK != SendATCmdWaitResp(buff, 500, 100, ">>>", 1)) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }
  SimpleWrite(p_buff, len);
  if ( RX_FINISHED_STR_RECV != WaitResp(500, 2000, str_ok) ) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }

  if ( RX_FINISHED_STR_RECV != WaitResp(10000, 1000, str_ok) ) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }

  if (!IsStringReceived("+SEND")) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }
  return 0;
}


int IOTModule::IotDataQury(int *p_len)
{
  char *p_char;
  char *p_char1;
  int len = 0;

  SimpleWriteln("AT+DQ?");
  if (RX_FINISHED_STR_RECV != WaitResp(500, 100, str_ok)) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }

  if (!IsStringReceived("+DQ")) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }
  p_char = strchr((char *)comm_buf, ':');
  p_char1 = p_char + 1;
  p_char = strchr((char *)p_char1, '\r');

  len = atoi(p_char1);
  *p_len = len;
  return 0;
}

int IOTModule::IotDataRcv(byte *p_buff, int len)
{
  SimpleWriteln("AT+RCV=1");
  if (RX_FINISHED_STR_RECV != WaitChunkResp(500, 3000, len)) {
    Serial.print("error "); Serial.println(__LINE__);
    return -1;
  }
  memcpy(p_buff, comm_buf, len);
  return 0;
}

int IOTModule::IotDataParse(uint8_t *p_buff, int len, IotRcvData_t *rcvDataArray, uint8_t *rcvDataArrayLen)
{
  uint8_t dataParsedLen = 0;
  uint8_t subPktLen = 0;
  uint32_t subPktId = 0;

  uint8_t arrayLen = 0;

  do {
    subPktLen = p_buff[dataParsedLen++];

    subPktId = uint32_decode(&p_buff[dataParsedLen]);
    dataParsedLen += 4;

    rcvDataArray[arrayLen].id = subPktId;
    rcvDataArray[arrayLen].data_len = subPktLen - 4;

    memcpy(rcvDataArray[arrayLen].data, &p_buff[dataParsedLen], subPktLen - 4);
    dataParsedLen += subPktLen - 4;
    arrayLen++;
    Serial.print("dataParsedLen = "); Serial.println(dataParsedLen);
  } while (dataParsedLen < len);

  *rcvDataArrayLen = arrayLen;
  return 0;
}


int IOTModule::BleDataSet(byte *p_buff, int len)
{
  char buff[20];
  sprintf(buff, "AT+BD=%u", len);

  if (AT_RESP_OK != SendATCmdWaitResp(buff, 500, 100, ">>>", 1)) {
#ifdef DEBUG    
    Serial.print("error "); Serial.println(__LINE__);
#endif    
    return -1;
  }

  SimpleWrite(p_buff, len);

  if ( RX_FINISHED_STR_RECV != WaitResp(500, 100, str_ok) ) {
#ifdef DEBUG        
    Serial.print("error "); Serial.println(__LINE__);
#endif    
    return -1;
  }

  return 0;
}
int IOTModule::BleTxpIntvSet(int8_t txp, uint16_t intv)
{
  char buff[20];
  sprintf(buff, "AT+BPI=%u,%u", txp, intv);

  if (AT_RESP_OK != SendATCmdWaitResp(buff, 500, 500, str_ok, 1)) {
    return -1;
  }

  return 0;
}
int IOTModule::BleTxpIntvGet(int8_t *p_txp, uint16_t *p_intv, uint8_t no_of_attempts)
{
  char *p_char;
  char *p_char1;
  int8_t txp = 0;
  uint16_t intv = 0;
  for(uint8_t i = 0; i < no_of_attempts; i++)
  {
    SimpleWriteln("AT+BPI?");
    if (RX_FINISHED_STR_RECV == WaitResp(500, 500, str_ok)) {
      break;
    }
  }

  if (!IsStringReceived("+BPI")) {
#ifdef DEBUG    
    Serial.print("error "); Serial.println(__LINE__);
#endif    
    return -1;
  }
  p_char = strchr((char *)comm_buf, ':');
  p_char1 = p_char + 1;
  p_char = strchr((char *)p_char1, ',');
  txp = atoi(p_char1);

  p_char1 = p_char + 1;
  p_char = strchr((char *)p_char1, '\r');

  intv = atoi(p_char1);

#ifdef DEBUG
  Serial.print("txp = ");
  Serial.println(*p_txp);
  Serial.print("intv = ");
  Serial.println(*p_intv);
#endif

  *p_txp = txp;
  *p_intv = intv;
  return 0;
}

