#ifndef _IOTMODULE_H
#define _IOTMODULE_H

#include <SoftwareSerial.h>
#include <Arduino.h>

#define UNO

#define COMM_BUF_LEN        64

#define RX_NOT_STARTED      0
#define RX_ALREADY_STARTED  1

#define str_ok     "OK"      //string to reduce stack usage
#define str_at    "AT"      //string to reduce stack usage

enum rx_state_enum {
  RX_NOT_FINISHED = 0,      // not finished yet
  RX_FINISHED,              // finished, some character was received
  RX_FINISHED_STR_RECV,     // finished and expected string received
  RX_FINISHED_STR_NOT_RECV, // finished, but expected string not received
  RX_TMOUT_ERR,             // finished, no character received
  // initial communication tmout occurred
  RX_LAST_ITEM
};

enum at_resp_enum {
  AT_RESP_ERR_NO_RESP = -1,   // nothing received
  AT_RESP_ERR_DIF_RESP = 0,   // response_string is different from the response
  AT_RESP_OK = 1,             // response_string was included in the response

  AT_RESP_LAST_ITEM
};

typedef struct {
  uint32_t id;
  uint8_t data[32];
  uint8_t data_len;
 }IotRcvData_t;

class IOTModule {

  private:
    byte comm_buf[COMM_BUF_LEN + 1]; // communication buffer +1 for 0x00 termination
    byte *p_comm_buf;               // pointer to the communication buffer
    byte comm_buf_len;              // num. of characters in the buffer
    byte rx_state;                  // internal state of rx state machine
    uint16_t start_reception_tmout; // max tmout for starting reception
    uint16_t interchar_tmout;       // previous time in msec.
    unsigned long prev_time;        // previous time in msec.

  protected:

    SoftwareSerial _ss;

    int _wakeupPin;

    byte WaitResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout,
                  char const *expected_resp_string);

   byte WaitChunkResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout,
                              uint8_t len);

    char SendATCmdWaitResp(char const *AT_cmd_string,
                           uint16_t start_comm_tmout,
                           uint16_t max_interchar_tmout,
                           char const *response_string,
                           byte no_of_attempts);

    char SendATCmdWaitResp(const __FlashStringHelper *AT_cmd_string,
                           uint16_t start_comm_tmout,
                           uint16_t max_interchar_tmout,
                           char const *response_string,
                           byte no_of_attempts);
    byte WaitResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout);
    byte IsRxFinished(void);
    byte IsStringReceived(char const *compare_string);
    void RxInit(uint16_t start_comm_tmout, uint16_t max_interchar_tmout);

    int available();

    uint8_t read();
    void SimpleRead();
    void SimpleWrite(uint8_t *p_buff, uint8_t len);
    void SimpleWrite(char *comm);
    void SimpleWrite(const char *comm);
    void SimpleWrite(int comm);
    void SimpleWrite(const __FlashStringHelper *pgmstr);
    void SimpleWriteln(char *comm);
    void SimpleWriteln(const __FlashStringHelper *pgmstr);
    void SimpleWriteln(char const *comm);
    void SimpleWriteln(int comm);
    void WhileSimpleRead();
    uint32_t uint32_decode(const uint8_t * p_encoded_data);

  public:

    IOTModule();
    int begin(long baud_rate);
    void wakeUp(void);
    void sleep(void);
    
    int IotSend(uint8_t *p_buff, uint8_t len, bool ack, uint32_t id);
    int IotDataQury(int *p_len);
    int IotDataRcv(byte *p_buff, int len);
    int IotDataParse(uint8_t *p_buff, int len, IotRcvData_t *rcvDataArray, uint8_t *rcvDataArrayLen);
    int BleDataSet(byte *p_buff, int len);
    int BleTxpIntvSet(int8_t txp, uint16_t intv);
    int BleTxpIntvGet(int8_t *p_txp, uint16_t *p_intv, uint8_t no_of_attempts);

};


#endif

