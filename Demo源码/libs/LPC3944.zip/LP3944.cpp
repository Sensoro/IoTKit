#include "LP3944.h"
#include <Wire.h>

LP3944:: LP3944(uint8_t address)
{
  _address = address;
}

bool LP3944:: begin(void)
{
  bool success = true;
  success &= writeReg(LP3944_REG_LS0, 0);
  success &= writeReg(LP3944_REG_LS1, 0);
  return success;
}

bool LP3944::writeReg(uint8_t reg, uint8_t value)
{
  int status = 0;
  Wire.beginTransmission(_address);
  Wire.write(reg);
  Wire.write(value);
  status = Wire.endTransmission(true);
  if ( 0 != status) {
    return false;
  }
  return true;
}


bool LP3944::readReg(uint8_t reg, uint8_t *val)
{
  int status = 0;
  uint8_t value;

  Wire.beginTransmission(_address);
  Wire.write(reg);
  status = Wire.endTransmission(false);
  if ( 0 != status) {
    return false;
  }
  Wire.requestFrom(_address, (uint8_t)1);
  int counter = 0;
  while (Wire.available() < 1)
  {
    counter++;
    delay(10);
    if (counter > 250)
      return false;
  }
  value = Wire.read();
  if ( 0 != status) {
    return false;
  }

  *val = value;
  return true;
}


bool LP3944::setDimPeriod(uint8_t dim, uint16_t period)
{
  uint8_t psc_reg;
  uint8_t psc_value;
  bool success = true;

  if (dim == LP3944_DIM0)
    psc_reg = LP3944_REG_PSC0;
  else if (dim == LP3944_DIM1)
    psc_reg = LP3944_REG_PSC1;
  else
    return false;

  /* Convert period to Prescaler value */
  if (period > LP3944_PERIOD_MAX)
    return false;

  psc_value = (period * 255) / LP3944_PERIOD_MAX;

  success = writeReg(psc_reg, psc_value);

  return success;
}

bool LP3944::setDimDutycycle(uint8_t dim, uint8_t duty_cycle)
{
  uint8_t pwm_reg;
  uint8_t pwm_value;
  bool success = true;

  if (dim == LP3944_DIM0)
    pwm_reg = LP3944_REG_PWM0;
  else if (dim == LP3944_DIM1)
    pwm_reg = LP3944_REG_PWM1;
  else
    return false;

  /* Convert duty cycle to PWM value */
  if (duty_cycle > LP3944_DUTY_CYCLE_MAX)
    return false;

  pwm_value = (duty_cycle * 255) / LP3944_DUTY_CYCLE_MAX;

  success = writeReg(pwm_reg, pwm_value);

  return success;
}

bool LP3944::setDimDutycycleHex(uint8_t dim, uint8_t duty_cycle)
{
  uint8_t pwm_reg;
  bool success = true;

  if (dim == LP3944_DIM0)
    pwm_reg = LP3944_REG_PWM0;
  else if (dim == LP3944_DIM1)
    pwm_reg = LP3944_REG_PWM1;
  else
    return false;

  success = writeReg(pwm_reg, duty_cycle);

  return success;
}

bool LP3944::setLedStatus(uint8_t led_id, uint8_t status)
{
  uint8_t id = led_id;
  uint8_t reg;
  uint8_t val = 0;
  int success = true;

  switch (id) {
    case LP3944_LED0:
    case LP3944_LED1:
    case LP3944_LED2:
    case LP3944_LED3:
      reg = LP3944_REG_LS0;
      break;
    case LP3944_LED4:
    case LP3944_LED5:
    case LP3944_LED6:
    case LP3944_LED7:
      id -= LP3944_LED4;
      reg = LP3944_REG_LS1;
      break;
    default:
      return false;
  }

  if (status > LP3944_LED_STATUS_DIM1)
    return false;

  /*
     Invert status only when it's < 2 (i.e. 0 or 1) which means it's
     controlling the on/off state directly.
     When, instead, status is >= 2 don't invert it because it would mean
     to mess with the hardware blinking mode.
  */
//  if (led->type == LP3944_LED_TYPE_LED_INVERTED && status < 2)
//    status = 1 - status;

  success = readReg(reg, &val);
  if (!success)
  {
    return false;
  }

  val &= ~(LP3944_LED_STATUS_MASK << (id << 1));
  val |= (status << (id << 1));

  /* set led status */
  success = writeReg(reg, val);

  return success;
}

bool LP3944::test(void)
{
  bool success = true;
  uint8_t val;
  success = writeReg(LP3944_REG_REGISTER8, 0x55);
  success &= readReg(LP3944_REG_REGISTER8, &val);
  success &= (val == 0x55);

  return success;
}



