#ifndef _LP3944_H
#define _LP3944_H

#include <Arduino.h>

/* Read Only Registers */
#define LP3944_I2C_ADDR       0X60<<1

#define LP3944_REG_INPUT1     0x00 /* LEDs 0-7 InputRegister (Read Only) */
#define LP3944_REG_REGISTER1  0x01 /* None (Read Only) */

#define LP3944_REG_PSC0       0x02 /* Frequency Prescaler 0 (R/W) */
#define LP3944_REG_PWM0       0x03 /* PWM Register 0 (R/W) */
#define LP3944_REG_PSC1       0x04 /* Frequency Prescaler 1 (R/W) */
#define LP3944_REG_PWM1       0x05 /* PWM Register 1 (R/W) */
#define LP3944_REG_LS0        0x06 /* LEDs 0-3 Selector (R/W) */
#define LP3944_REG_LS1        0x07 /* LEDs 4-7 Selector (R/W) */

/* These registers are not used to control leds in LP3944, they can store
 * arbitrary values which the chip will ignore.
 */
#define LP3944_REG_REGISTER8  0x08
#define LP3944_REG_REGISTER9  0x09

#define LP3944_DIM0 0
#define LP3944_DIM1 1

/* period in ms */
#define LP3944_PERIOD_MIN 0
#define LP3944_PERIOD_MAX 1600

/* duty cycle is a percentage */
#define LP3944_DUTY_CYCLE_MIN 0
#define LP3944_DUTY_CYCLE_MAX 100

#define LP3944_LED0 0
#define LP3944_LED1 1
#define LP3944_LED2 2
#define LP3944_LED3 3
#define LP3944_LED4 4
#define LP3944_LED5 5
#define LP3944_LED6 6
#define LP3944_LED7 7
#define LP3944_LEDS_MAX 8

#define LP3944_LED_STATUS_MASK  0x03

enum lp3944_status {
  LP3944_LED_STATUS_OFF  = 0x0,
  LP3944_LED_STATUS_ON   = 0x1,
  LP3944_LED_STATUS_DIM0 = 0x2,
  LP3944_LED_STATUS_DIM1 = 0x3
};

class LP3944 {

  public:
    LP3944(uint8_t address);
    bool begin(void);

    bool setDimPeriod(uint8_t dim, uint16_t period);
    bool setDimDutycycle(uint8_t dim, uint8_t duty_cycle);

    bool setDimDutycycleHex(uint8_t dim, uint8_t duty_cycle);
    bool setLedStatus(uint8_t led_id, uint8_t status);
    bool test(void);


  private:
    uint8_t _address;

    bool writeReg(uint8_t reg, uint8_t value);
    bool readReg(uint8_t reg, uint8_t *p_val);


};

#endif


