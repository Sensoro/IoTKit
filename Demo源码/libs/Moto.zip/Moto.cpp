#include "Moto.h"
#include "Arduino.h"

Moto::Moto(int anodePin,int cathodePin){
  _anodePin = anodePin;
  _cathodePin = cathodePin;
}
void Moto::begin(void){
  pinMode(_anodePin,OUTPUT);
  pinMode(_cathodePin,OUTPUT);
  digitalWrite(_anodePin,LOW);
  digitalWrite(_cathodePin,LOW);
  _state = STOP;
}
void Moto::rotate(void){
  if(_state!=ROTATE)
  {
    _state = ROTATE;
    digitalWrite(_cathodePin,LOW);
    digitalWrite(_anodePin,HIGH); 
  }
}
void Moto::reversal(void){
  if(_state != REVERSAL)
  {
    _state = REVERSAL;
    digitalWrite(_cathodePin,HIGH);
    digitalWrite(_anodePin,LOW);
  }
}
void Moto::stop(void){
  if(_state != STOP)
  {
    _state = STOP;
    digitalWrite(_anodePin,LOW);
    digitalWrite(_cathodePin,LOW);
  }
}

